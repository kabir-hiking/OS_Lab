#include<bits/stdc++.h>
#include <fstream>
#include <sys/stat.h>
#include <unistd.h>
#include <ctime>
#include <cstring>
using namespace std;

int main() {
   string filename = "value.txt"; 
    struct stat fileStat;
    
    if(stat(filename.c_str(), &fileStat) == 0) {
    
       cout << "Permissions: ";
       cout << ((S_ISDIR(fileStat.st_mode)) ? "d" : "-");
       cout << ((fileStat.st_mode & S_IRUSR) ? "r" : "-");
       cout << ((fileStat.st_mode & S_IWUSR) ? "w" : "-");
       cout << ((fileStat.st_mode & S_IXUSR) ? "x" : "-");
       cout << ((fileStat.st_mode & S_IRGRP) ? "r" : "-");
       cout << ((fileStat.st_mode & S_IWGRP) ? "w" : "-");
       cout << ((fileStat.st_mode & S_IXGRP) ? "x" : "-");
       cout << ((fileStat.st_mode & S_IROTH) ? "r" : "-");
       cout << ((fileStat.st_mode & S_IWOTH) ? "w" : "-");
       cout << ((fileStat.st_mode & S_IXOTH) ? "x" : "-");
       cout <<endl;
        
        
       cout << "Creation Time: " << ctime(&fileStat.st_ctime);
        
       
       cout << "Modification Time: " << ctime(&fileStat.st_mtime);
     
       cout << "Size: " << fileStat.st_size << " bytes" <<endl;

       cout << "File type: ";
        if (S_ISREG(fileStat.st_mode))
           cout << "Regular file" <<endl;
        else if (S_ISDIR(fileStat.st_mode))
           cout << "Directory" <<endl;
        else if (S_ISLNK(fileStat.st_mode))
           cout << "Symbolic link" <<endl;
        else if (S_ISCHR(fileStat.st_mode))
           cout << "Character device" <<endl;
        else if (S_ISBLK(fileStat.st_mode))
           cout << "Block device" <<endl;
        else if (S_ISFIFO(fileStat.st_mode))
           cout << "FIFO/pipe" <<endl;
        else if (S_ISSOCK(fileStat.st_mode))
           cout << "Socket" <<endl;
        
       
       cout << "Inode: " << fileStat.st_ino <<endl;
        
        // Check if it's a symbolic link or a hard link
        struct stat linkStat;
        if (lstat(filename.c_str(), &linkStat) == 0) {
            if (S_ISLNK(linkStat.st_mode))
               cout << "This is a symbolic link" <<endl;
            else if (fileStat.st_nlink > 1)
               cout << "This is a hard link" <<endl;
        }
    }
    else {
       cerr << "Error: Unable to access file." <<endl;
    }

    return 0;
}
